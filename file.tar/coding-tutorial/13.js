let i = -5
for (i = -5; i <= 5; i++) {
    console.log(i);
}