let message = "hello world!";
// ^^^ message is a variable.
console.log(message);
