let i = 1

let k = i + 5

console.log(k)