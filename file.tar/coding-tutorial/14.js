let prompt = require("prompt-sync")();

let firstName = prompt("Enter your first name: ");

let lastName = prompt("Enter your last name: ");
let age = prompt("enter age: ");
console.log(firstName + lastName);
if (age < 18) {
  console.log("you are less then 18");
  console.log("you need", 18 - age, "years");
} else {
  console.log("Contrats you are eligible...");
}
