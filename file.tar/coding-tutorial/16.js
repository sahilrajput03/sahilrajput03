// todo: function learning.
