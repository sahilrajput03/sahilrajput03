// variables
let firstname = "Khushi";
let lastname = " Khan";
console.log(firstname + lastname);
